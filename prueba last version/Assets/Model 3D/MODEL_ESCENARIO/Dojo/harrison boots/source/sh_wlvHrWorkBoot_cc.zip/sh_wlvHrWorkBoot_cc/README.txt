** Wolverine Men's Harrison Lace-Up 6" Work Boot **

*100% Imported Leather Hard-working boot featuring contrast cushioned collar and logos at tongue and outstep panels with synthetic sole.*

*30.7 x 11.0 x 20.2 cm (115 micrometers per texel @ 4k)*

Scanned using advanced technology developed by inciprocal Inc. that enables highly photo-realistic reproduction of real-world products in virtual environments. Our hardware and software technology combines advanced photometry, structured light, photogrammtery and light fields to capture and generate accurate material representations from tens of thousands of images targeting real-time and offline path-traced PBR compatible renderers.

Zip file includes low-poly OBJ mesh (in meters) with a set of 4k PBR textures compressed with *lossless* JPEG (no chroma sub-sampling).

Copyright (C) 2022 inciprocal Inc.
This work is licensed under a Creative Commons Attribution 4.0 International (CC BY 4.0) License.
